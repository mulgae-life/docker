#!/bin/bash
# usage: fetch2.sh <gallery_id> <post_no> [board_kind: board|mini]
UA="Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
D=/tmp/claude-1000/-workspace-docker/bc4819b4-4211-4375-8a2c-fa8f2ffdabe5/scratchpad/dc
K=${3:-board}
curl -sL --max-time 30 -A "$UA" "https://m.dcinside.com/$K/$1/$2" -o "$D/$1_$2.html"
python3 "$D/clean.py" "$D/$1_$2.html"
