import re,html,sys,subprocess,urllib.parse
gid=sys.argv[1]; kw=sys.argv[2]
stype=sys.argv[3] if len(sys.argv)>3 else 'search_subject_memo'
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
q=urllib.parse.quote(kw)
url=f"https://gall.dcinside.com/mgallery/board/lists/?id={gid}&s_type={stype}&s_keyword={q}"
h=subprocess.run(["curl","-sL","--max-time","40","-A",UA,"-H",f"Referer: https://gall.dcinside.com/mgallery/board/lists/?id={gid}",url],capture_output=True,text=True).stdout
rows=re.findall(r'(?is)<tr>\s*<td class="gall_num">.*?</tr>',h)
out=[]
for r in rows:
    m=re.search(r'href="[^"]*?id=([a-zA-Z0-9_]+)&(?:amp;)?no=(\d+)[^"]*"[^>]*>(.*?)</a>',r)
    if not m: continue
    gg,no,t=m.group(1),m.group(2),m.group(3)
    t=re.sub(r'\s+',' ',html.unescape(re.sub(r'(?is)<[^>]+>',' ',t))).strip()
    dm=re.search(r'(?is)<td class="gall_date"[^>]*>([^<]*)<',r)
    d=dm.group(1).strip() if dm else ''
    out.append((gg,no,d,t))
print(f"### KW={kw} rows={len(out)}")
for gg,no,d,t in out:
    print(f"{gg}|{no}|{d}|{t}")
