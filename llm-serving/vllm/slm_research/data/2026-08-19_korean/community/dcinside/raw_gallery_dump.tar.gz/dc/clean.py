import re,html,sys
h=open(sys.argv[1],encoding='utf-8',errors='replace').read()
h=re.sub(r'(?is)<script.*?</script>','',h)
h=re.sub(r'(?is)<style.*?</style>','',h)
t=re.sub(r'(?is)<br\s*/?>','\n',h)
t=re.sub(r'(?is)</(p|div|li|dd|dt|h\d|tr)>','\n',t)
t=re.sub(r'(?is)<[^>]+>',' ',t)
t=html.unescape(t)
t=re.sub(r'[ \t]+',' ',t)
t=re.sub(r'\n\s*\n+','\n',t)
lines=[l.strip() for l in t.split('\n')]
# cut boilerplate header: start after "이용자 메모"/"신뢰할 수 있는 사이트" region
start=0
for i,l in enumerate(lines):
    if l.startswith('[') and l.endswith(']') and i>20: start=i; break
    if '신뢰할 수 있는 사이트' in l: start=i+1
end=len(lines)
for i,l in enumerate(lines):
    if i>start and ('갤닉네임 사용' in l or "'로갤러'는" in l or '보이스리플' in l): end=i; break
print('\n'.join([l for l in lines[start:end] if l]))
