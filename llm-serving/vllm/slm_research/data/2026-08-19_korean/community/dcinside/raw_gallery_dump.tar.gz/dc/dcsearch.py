import re,html,sys,subprocess,urllib.parse
kw=sys.argv[1]; pages=int(sys.argv[2]) if len(sys.argv)>2 else 2
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
q=urllib.parse.quote(kw)
print(f"##### SEARCH: {kw}")
for p in range(1,pages+1):
    url=f"https://search.dcinside.com/post/p/{p}/sort/latest/q/{q}"
    h=subprocess.run(["curl","-sL","--max-time","30","-A",UA,"-H","Referer: https://www.dcinside.com/",url],capture_output=True,text=True).stdout
    blocks=re.split(r'<li class="sch_result_list"|<ul class="sch_result_list"',h)
    for b in re.findall(r'<a href="(https?://gall\.dcinside\.com/[^"]*?id=([a-zA-Z0-9_]+)&(?:amp;)?no=(\d+)[^"]*)"[^>]*>(.*?)</a>',h,re.S):
        link,gid,no,inner=b
        if gid in ('dcbest','dcnews'): continue
        t=re.sub(r'(?is)<[^>]+>','',inner); t=re.sub(r'\s+',' ',html.unescape(t)).strip()
        if len(t)<3: continue
        print(f"{gid} | {no} | {t[:110]}")
