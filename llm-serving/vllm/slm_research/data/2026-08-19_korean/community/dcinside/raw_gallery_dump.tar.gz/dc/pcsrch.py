import re,html,sys,subprocess,urllib.parse
gid=sys.argv[1]; kw=sys.argv[2]
board=sys.argv[3] if len(sys.argv)>3 else 'mgallery'
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
q=urllib.parse.quote(kw)
base="https://gall.dcinside.com/"+(board+"/" if board else "")+"board/lists/"
url=f"{base}?id={gid}&s_type=search_subject_memo&s_keyword={q}"
h=subprocess.run(["curl","-sL","--max-time","30","-A",UA,"-H","Referer: https://gall.dcinside.com/",url],capture_output=True,text=True).stdout
rows=re.findall(r'<tr class="ub-content[^"]*"(.*?)</tr>',h,re.S)
print(f"### {gid} KW={kw} rows={len(rows)}")
for r in rows:
    m=re.search(r'href="[^"]*?no=(\d+)',r)
    t=re.search(r'class="gall_tit[^"]*">(.*?)</td>',r,re.S)
    d=re.search(r'class="gall_date"[^>]*title="([^"]*)"',r)
    if not m: continue
    title=re.sub(r'(?is)<[^>]+>',' ',t.group(1)) if t else ''
    title=re.sub(r'\s+',' ',html.unescape(title)).strip()
    print(m.group(1),'|',d.group(1) if d else '','|',title)
