import re,html,sys,subprocess,urllib.parse
gid=sys.argv[1]; kw=sys.argv[2]
UA="Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
q=urllib.parse.quote(kw)
url=f"https://m.dcinside.com/board/{gid}?s_type=search_subject_memo&serval={q}"
h=subprocess.run(["curl","-sL","--max-time","30","-A",UA,url],capture_output=True,text=True).stdout
seen={}
for m in re.finditer(r'href="[^"]*?/board/'+gid+r'/(\d+)[^"]*?"[^>]*>(.*?)</a>',h,re.S):
    no=m.group(1); inner=m.group(2)
    if 'comment_box' in m.group(0): continue
    txt=re.sub(r'(?is)<[^>]+>',' ',inner); txt=html.unescape(txt); txt=re.sub(r'\s+',' ',txt).strip()
    if not txt or len(txt)<2: continue
    if no not in seen or len(txt)>len(seen[no]): seen[no]=txt
print(f"### KW={kw}  hits={len(seen)}")
for no in sorted(seen,key=lambda x:-int(x)):
    print(no,'|',seen[no])
