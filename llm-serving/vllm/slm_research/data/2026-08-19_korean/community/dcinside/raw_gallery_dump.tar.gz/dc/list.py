import re,html,sys,subprocess,urllib.parse
gid=sys.argv[1]; pages=int(sys.argv[2]) if len(sys.argv)>2 else 3
extra=sys.argv[3] if len(sys.argv)>3 else ''
UA="Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
seen={}
for p in range(1,pages+1):
    url=f"https://m.dcinside.com/board/{gid}?page={p}{extra}"
    h=subprocess.run(["curl","-sL","--max-time","30","-A",UA,url],capture_output=True,text=True).stdout
    # each list item: <a href=".../board/gid/NO...">  ... <strong ...>title</strong> or span subject
    for m in re.finditer(r'href="[^"]*?/board/'+gid+r'/(\d+)[^"]*?"[^>]*>(.*?)</a>',h,re.S):
        no=m.group(1); inner=m.group(2)
        if 'comment_box' in m.group(0): continue
        txt=re.sub(r'(?is)<[^>]+>',' ',inner)
        txt=html.unescape(txt); txt=re.sub(r'\s+',' ',txt).strip()
        if not txt or len(txt)<2: continue
        if no not in seen or len(txt)>len(seen[no]): seen[no]=txt
for no in sorted(seen,key=lambda x:-int(x)):
    print(no,'|',seen[no])
